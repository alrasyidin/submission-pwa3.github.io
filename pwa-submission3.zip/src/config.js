const authToken = '5b1b442446754fbb8547ca7860b68860'
export const baseurl = 'https://api.football-data.org/v2/'
export const standing = `${baseurl}competitions/2021/standings`

export const headers = {
  headers: {
    'X-Auth-Token': authToken
  }
}